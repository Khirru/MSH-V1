<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="Wand Verlauf Leiste" tilewidth="32" tileheight="32" tilecount="6" columns="3">
 <image source="Wand Verlauf Leiste.png" width="96" height="64"/>
</tileset>
